-- MySQL dump 10.13  Distrib 8.4.3, for Win64 (x86_64)
--
-- Host: localhost    Database: kedaipisauhrsuccess
-- ------------------------------------------------------
-- Server version	8.4.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_logs_user_id_foreign` (`user_id`),
  KEY `activity_logs_created_at_type_index` (`created_at`,`type`),
  CONSTRAINT `activity_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES (1,'item_created','Item \'Skinning Knife 12,5 cm\' was created','31040','{\"brand\": \"PiRGE\", \"model\": \"Duo\", \"sku_id\": \"31040-01\", \"quantity\": 0}',1,'2025-09-03 18:25:03','2025-09-03 18:25:03'),(2,'stock_in','Stock added to \'Skinning Knife 12,5 cm\' - 24 units','31040','{\"reason\": \"purchase\", \"quantity\": 24, \"batch_number\": \"3104064\", \"balance_after\": 24}',1,'2025-09-03 18:25:53','2025-09-03 18:25:53'),(3,'stock_in','Stock added to \'Skinning Knife 12,5 cm\' - 24 units','31040','{\"reason\": \"purchase\", \"quantity\": 24, \"batch_number\": \"3104026\", \"balance_after\": 48}',1,'2025-09-03 18:26:21','2025-09-03 18:26:21'),(4,'stock_out','Stock removed from \'Skinning Knife 12,5 cm\' - 1 units','31040','{\"reason\": \"Sumbing\", \"quantity\": 1, \"batch_number\": \"3104064\", \"balance_after\": 47}',1,'2025-09-03 18:26:59','2025-09-03 18:26:59'),(5,'item_updated','Item \'iPhone 15 Pro Max\' was updated','ITM-000001','{\"brand\": \"PiRGE\", \"model\": \"Duo\", \"sku_id\": \"APL-IP15-BLK-001\", \"quantity\": 0}',1,'2025-09-03 18:29:26','2025-09-03 18:29:26'),(6,'item_updated','Item \'Samsung Galaxy S24\' was updated','ITM-000002','{\"brand\": \"PiRGE\", \"model\": \"Duo\", \"sku_id\": \"SAM-GAL-WHT-002\", \"quantity\": 0}',1,'2025-09-03 18:29:43','2025-09-03 18:29:43'),(7,'item_created','Item \'Skninning Knife\' was created','45678','{\"brand\": \"Atasan\", \"model\": \"Gold\", \"sku_id\": \"45678-01\", \"quantity\": 0}',1,'2025-09-04 02:39:58','2025-09-04 02:39:58'),(8,'item_deleted','Item \'iPhone 15 Pro Max\' was deleted',NULL,'{\"brand\": \"PiRGE\", \"model\": \"Duo\", \"sku_id\": \"APL-IP15-BLK-001\", \"item_id\": \"ITM-000001\", \"quantity\": 0, \"item_name\": \"iPhone 15 Pro Max\"}',1,'2025-09-04 02:40:14','2025-09-04 02:40:14'),(9,'item_deleted','Item \'Skninning Knife\' was deleted',NULL,'{\"brand\": \"Atasan\", \"model\": \"Gold\", \"sku_id\": \"45678-01\", \"item_id\": \"45678\", \"quantity\": 0, \"item_name\": \"Skninning Knife\"}',1,'2025-09-04 03:42:02','2025-09-04 03:42:02'),(10,'item_updated','Item \'Samsung Galaxy S24\' was updated','ITM-000002','{\"brand\": \"PiRGE\", \"model\": \"Duo\", \"sku_id\": \"SAM-GAL-WHT-002\", \"quantity\": 0}',1,'2025-09-04 03:42:08','2025-09-04 03:42:08'),(11,'item_created','Item \'Haptic Feedback Knife\' was created','45676','{\"brand\": \"Atasan\", \"model\": \"Gold\", \"sku_id\": \"45676-01\", \"quantity\": 0}',1,'2025-09-04 03:42:53','2025-09-04 03:42:53'),(12,'stock_in','Stock added to \'Haptic Feedback Knife\' - 100 units','45676','{\"reason\": \"testing\", \"quantity\": 100, \"batch_number\": \"4567614\", \"balance_after\": 100}',1,'2025-09-04 03:44:30','2025-09-04 03:44:30'),(13,'stock_out','Stock removed from \'Haptic Feedback Knife\' - 2 units','45676','{\"reason\": \"sumbing\", \"quantity\": 2, \"batch_number\": \"4567614\", \"balance_after\": 98}',1,'2025-09-04 03:44:51','2025-09-04 03:44:51');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brands` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brands_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (1,'PiRGE','2025-09-03 18:23:25','2025-09-03 18:23:25'),(2,'Jaya Mata','2025-09-03 18:23:33','2025-09-03 18:23:33'),(3,'Atasan','2025-09-03 18:23:38','2025-09-03 18:23:38');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `colors`
--

DROP TABLE IF EXISTS `colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `colors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_id` bigint unsigned NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `colors_name_brand_id_model_id_unique` (`name`,`brand_id`,`model_id`),
  KEY `colors_brand_id_foreign` (`brand_id`),
  KEY `colors_model_id_foreign` (`model_id`),
  CONSTRAINT `colors_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `colors_model_id_foreign` FOREIGN KEY (`model_id`) REFERENCES `models` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colors`
--

LOCK TABLES `colors` WRITE;
/*!40000 ALTER TABLE `colors` DISABLE KEYS */;
INSERT INTO `colors` VALUES (1,'Black',1,1,'2025-09-03 18:24:01','2025-09-03 18:24:01'),(2,'No Color',3,2,'2025-09-04 02:39:20','2025-09-04 02:39:20');
/*!40000 ALTER TABLE `colors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `damaged_items`
--

DROP TABLE IF EXISTS `damaged_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `damaged_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `item_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `damage_reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `damaged_items_item_id_index` (`item_id`),
  KEY `damaged_items_user_id_foreign` (`user_id`),
  CONSTRAINT `damaged_items_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `damaged_items`
--

LOCK TABLES `damaged_items` WRITE;
/*!40000 ALTER TABLE `damaged_items` DISABLE KEYS */;
INSERT INTO `damaged_items` VALUES (1,'31040',1,'Sumbing','3104064',1,'2025-09-03 18:26:59','2025-09-03 18:26:59'),(2,'45676',2,'sumbing','4567614',1,'2025-09-04 03:44:51','2025-09-04 03:44:51');
/*!40000 ALTER TABLE `damaged_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `export_notifications`
--

DROP TABLE IF EXISTS `export_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `export_notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filters` json DEFAULT NULL,
  `status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` int DEFAULT NULL,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `export_notifications_user_id_status_index` (`user_id`,`status`),
  KEY `export_notifications_created_at_index` (`created_at`),
  CONSTRAINT `export_notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `export_notifications`
--

LOCK TABLES `export_notifications` WRITE;
/*!40000 ALTER TABLE `export_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `export_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `item_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `barcode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cost_price` decimal(10,2) NOT NULL,
  `retail_price` decimal(10,2) NOT NULL,
  `quantity` int NOT NULL DEFAULT '0',
  `status` enum('out_of_stock','low_stock','ready_stock') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'out_of_stock',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `items_item_id_unique` (`item_id`),
  UNIQUE KEY `items_sku_id_unique` (`sku_id`),
  UNIQUE KEY `items_barcode_unique` (`barcode`),
  KEY `items_item_id_index` (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,'31040','31040-01','3104001','Skinning Knife 12,5 cm','PiRGE','Duo','Black','Brand Made in Turkey','items/item_2025-09-04_02-25-00_L3XjhxVz.JPG',100.00,200.00,47,'ready_stock','2025-09-03 18:25:03','2025-09-03 18:26:59'),(3,'ITM-000002','SAM-GAL-WHT-002','234567890123467277','Samsung Galaxy S24','PiRGE','Duo','Black','Premium Android smartphone','items/item_2025-09-04_02-29-43_GwwxmXrj.JPG',3200.00,4299.00,0,'out_of_stock','2025-09-03 18:28:45','2025-09-04 03:42:08'),(5,'45676','45676-01','4567601','Haptic Feedback Knife','Atasan','Gold','No Color','22','items/item_2025-09-04_11-42-51_9GyLridm.png',2.00,2.00,98,'ready_stock','2025-09-04 03:42:53','2025-09-04 03:44:51');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2025_01_20_000000_remove_remember_token_from_users_table',1),(6,'2025_08_17_074713_modify_users_table_add_names_role_status',1),(7,'2025_08_17_095824_create_items_table',1),(8,'2025_08_17_095829_create_brands_table',1),(9,'2025_08_17_095835_create_models_table',1),(10,'2025_08_17_095841_create_colors_table',1),(11,'2025_08_17_112139_update_items_table_make_barcode_required',1),(12,'2025_08_17_122131_update_items_table_for_r2_storage',1),(13,'2025_08_17_132907_create_model_color_table',1),(14,'2025_08_17_133742_remove_hex_code_from_colors_table',1),(15,'2025_08_17_135548_restructure_colors_with_brand_model_foreign_keys',1),(16,'2025_08_17_163432_create_stock_movements_table',1),(17,'2025_08_18_002344_create_stock_batches_table',1),(18,'2025_08_18_013140_add_expiry_date_to_stock_batches_table',1),(19,'2025_08_18_014447_add_status_to_stock_batches_table',1),(20,'2025_08_18_090908_add_batch_number_to_stock_movements_table',1),(21,'2025_08_18_111706_remove_remember_token_from_users_table',1),(22,'2025_08_19_113254_fix_colors_unique_constraint',1),(23,'2025_08_20_063357_create_activity_logs_table',1),(24,'2025_08_30_145027_add_destination_to_stock_movements_table',1),(25,'2025_08_30_150111_add_other_destination_to_stock_movements_table',1),(26,'2025_08_30_155236_create_damaged_items_table',1),(27,'2025_09_01_115543_remove_destination_fields_from_stock_movements_table',1),(28,'2025_09_02_104319_create_jobs_table',1),(29,'2025_09_02_104611_create_export_notifications_table',1),(30,'2025_09_04_104509_create_sessions_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `models`
--

DROP TABLE IF EXISTS `models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `models` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `models_name_brand_id_unique` (`name`,`brand_id`),
  KEY `models_brand_id_foreign` (`brand_id`),
  CONSTRAINT `models_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `models`
--

LOCK TABLES `models` WRITE;
/*!40000 ALTER TABLE `models` DISABLE KEYS */;
INSERT INTO `models` VALUES (1,'Duo',1,'2025-09-03 18:23:48','2025-09-03 18:23:48'),(2,'Gold',3,'2025-09-04 02:39:10','2025-09-04 02:39:10');
/*!40000 ALTER TABLE `models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('1AdNDDD3cxRubofLLOYBVj77DrJFfNI41Q9g05c9',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-MY) WindowsPowerShell/5.1.26100.4768','ZXlKcGRpSTZJbGt4T1dORVZqTnBlbVJTYXpKclEwUXhUbEZNUmxFOVBTSXNJblpoYkhWbElqb2lhbmR2YnpsMlpWWjVSemxYZFdoR2JrdDZkRkJrZVV0NlEySllabkJoZURGQ056Tm1RUzlKVXpOV2J6TnZOWFo2UTBGYVZrOXVNRFpKUzJweVRqZGxZWFpXS3l0T1FuQmlTMkp5Y1RaVFluUXdkMHRpV21Fek1tNDFaVmRQVGxOM1pYSmhUMVI0UzNSdE1IcEtUMHBJTlZFeGQycG9LMGxzZUdWM1VtdFJRa1o2Y0ZoVUwyNU9RelY0VWpGelFsQXpPRXhwVUV4eVRXTkVhR1E0UkhKTUwzcGphMUp1TWpoeGRsSk5hM1ZIWTNkWlQyRnBZbTAwVURSdVlYaDFaV1ZMWnpkVmVWVlNiR05EV2poaVYyRjRWR05ZVEZoNFFucDNTSEpJZUd4Qk5taFFOMmRGWTNkWVNIUjJiako0TVdKYWVVNWlPVlZtY2tJM1JubFJaRmRZTldkcFJGUnpORTFsY21KNFJHMXhTR1ZLYzB4NU5XZExUbVJtTUdZME5uTmpVMWczZVZSRWEzTlBRblJQTldaS1VrNUljRTlzVVM5WllYZFNVR3B2VTFsQk0xUmtiVU5rZFc4M2VIbDRjRGxJUkcxT1YydDJXVVJ4ZVRodlNXOHlTbTVtTmxBMmR6RldRWGhvYUVOQ1FVaE5kVFJVTjFSQ2VteHdNVVpHYkhoa2EzaGxhVUl5ZUVndkszaHJkWEkwZEhCelQzQnBVRGxPVEZVeFNUZEZPUzl5VEVwR1RsVnNhMFptWnowaUxDSnRZV01pT2lJNE5UQmhZbVV6TVRFek4yRTFPR0ZpTnpoaE56VTFOR1V5TXpNNE1HRXlaV1pqTUdZMk5UTTNZVE15TVdFd01qTTVaakV4TUdaalpETTVOekJqWWpNNElpd2lkR0ZuSWpvaUluMD0=',1756954784),('5wX2LODJmpK9BWlwaAT6QPpI8PSPJMAKnt6cA4z1',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-MY) WindowsPowerShell/5.1.26100.4768','ZXlKcGRpSTZJamhSWTBkTFl6bEthemt6WVhkMFRVa3JabEZ2ZEZFOVBTSXNJblpoYkhWbElqb2lPVmRRS3psYVdFRTNVbWx2ZERKdVNtWkJZM1pVY21kdlRXOVNhbUlyU21NMlRUWjZiVFo1TmtSb1l6VmpaWFo1ZFVaNGFFTklaamxpYjJ0RFEwSllSREJzUTBONFFrbDJXVEU1ZDBGRGMwUldWMEY2VEhsSVNVdDZUak5ETDNsdUwwNUNaa05FTUZabGRrOVlOVTg1TTJjNEwyYzBjbmxZVGxJMGRrUXJja2xZTUZWUWIxTllWME4wTVdKSGVsWXpabGxNYkZoUWVWQlZlbUp6ZERGUFpUWkdNSEp5VFhWTlVqaFRlVUpMS3pkRGRucEtUM1ZOU3pneFNIVkxRV2d2V1VSU01FbE5UbnBLWXpac1NGaHVUMlJQYm1KUFRqQmlXR1ZZWm1aTlZEWTNSMGQyTUVVNVVWTjNXRlJ5YTBzdmJtYzBLM0prU1ZGd1IwWXpiVUpPTHpSTGFFZFhibEJ1VDNSMlEyZDVTVEpaYVd4dWNESkNlWGhCUnpoTmJVeE1aMkYyYkRGdlQwcHZTVmhIY1VaTmIwWnZTek56ZG5BeVZraEtaRFYwWm1FelVtdERTSEpMVkVaQ1ZHYzVaVU0wWVhWTE9HcDRaRGRWZVdJMllsUkRTbVJvYkU5UGFHNDJkMk0wY1V4UmJWZG9jVGs1YWtaVVUzTnJWa2RhTVV0blJXSndLelJ3YWlzMlFsWmtUMFZhVEhWVE5YSXdiRE5pVm10emIyc3ZTekUwWjNWNWNGRlpZM05WVVQwaUxDSnRZV01pT2lKbU5HWmxNek13TURVd1lUa3dPREk0WlRVeE5qbG1PRFkxTmpSbFpqRmpOemhoTmpCbU0yTTVZVEkzTm1ZMVptWmlOell6TXpnd05qUm1OekJpTUdGa0lpd2lkR0ZuSWpvaUluMD0=',1756955086),('fC4hsrepBNq9ghoQ6wxOD0miuCSNolypM4F34xff',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0','ZXlKcGRpSTZJbTFRTm0xNldVMTBRMG9yVkhVdmFWZE9XVWxvYjBFOVBTSXNJblpoYkhWbElqb2lhVTRyU0ZacFdsQlliMHRUVFZwWGJWWkplbmMwVXl0blJEbExNMHd3UzA1dFVEWlBObU00TUU0ellYbzBjM1JCVWpKeVVFNDNVSFJwY1RsWU1EazVWRVE1YVZkQ1NESm5kazFXYlRReWIzcGFaVmhCVDBZd1ExSm1LMmhvYkVOaFluaE1RbUpCYld0M01HSjNjV1ZYVm5kMk9Xc3lVazlsYUU5bWJ5OUthSFJ2Y1Zwa2VVUjZkWFZvUlcxT1oyWmhiRXh0YlRSeVdXcHRXakI1YkRWUlNXcHlWWHBuVUVoUmJUUktSbTlZUW1FeFdqUklRakZuZUVsdlZYaE5hWEpaZHpadllYWm9Na3RxZDFkRGNYcHROR054VTNaRmNtazBNbFU1UTNGd2FYWktTakp3WjIwek1VTldWRmN4ZEc1SVZVbzViRkZCV2tObWRXOWtRWEpGVFZCcllrOUhORGhxYXprdlVEbG5TbnBKU3k5aFVETTVlSGxTWlZwRmFrdFdlWHBUV2xOaFVVSklkVWRUUkZrclUxbEdhVWhoVEM4NWVTdHFaMkpyY2pWelpWVlFWR04xY1RjNFpXaEZXV2szUTFwM2RFZFljMHN4TWxCMVlsbE9hMjlrU205amVVMW1iR2t6TjBoUFlYRldRV1ZETjJ4NWVIRm5WbVl5ZW5JMk5HOHlVazFUV1VFNU1qTmhlakZpZWxkaGJXMHlTa1pQU2xscldIZHBVV3AxTHpGSFRrNVFTek5MWlZCS2FuZ3liMlYxSzFWV2RUQTFhMHBzVkdSTlRqWldjR05WVmtaNlkxQjRNVTE1ZW5STlZuTXJkMU5rWW5KMFNtTmhSRUpUUWxoMmNERkdOWGswVTJ0M2F6SlVVbmczYm1WUVdUbGtNREZIZURKNlZrRk5SMWd3VHpCalUyVmFTSEVyVTBGSlNVdENSMnB5VG5GREsxWTNiV3h1VjJadldHUm1ka2hIVW0wM1drcHNkWEUzVmk4NFJVaGhWR3MwWTI5SlptVnRVWGhtVW5GSFpqWmxOVTVDTVRSSFIwTXlibFZzYUhoVGJ6Z3dORzUzSzNKQmFIcG1kWE5UZFhZMGFHMDFNa1ZvY0RaNEwzSkhibU5qWms1YU1tUXhMMmxyZDNaTVUwWk9kQ3M1U1c1bFJUVjRaV2RLZDBFOVBTSXNJbTFoWXlJNklqWTNOakUyTm1NeFpUZ3pPV013WkRFM1pqazJOVFF6T1dVMU16SXlOalZqTkRFMFkyWTRZV0V3TlRGbFpXTmlNVFJqWVdRMlpqQTBPR0UxTjJJNVl6QWlMQ0owWVdjaU9pSWlmUT09',1756957514),('M9MGHSeslggoPpzVNL40FEjndfxq9EGb6RUSu1JP',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-MY) WindowsPowerShell/5.1.26100.4768','ZXlKcGRpSTZJbFY1ZWxaRUx6RlpUbTlTZGtOR2JFMHdRMnRWZEZFOVBTSXNJblpoYkhWbElqb2lVamhZWlU5TE1VRkNhekY2U1hORmNYY3lUVEpGVmt4aVZFOTBZMnRPY0ZkalQwOTFTVEkwU1RKTU4xZFZRbGh4UVZOM1lUWm1kalJrWlcwMlJESm5jRUZyTlZSVFJXbDJZVTA1TkU1R1pEWjJMMDAyYm5CelVFOUZNVTEyYnpWS2MxRnhTbWc1WWpsbGNHNU5kM1p0ZW1ob2FsRkZkVEZsV0hSV1pqaHNURTlWUTBaWVNsaE5kR3BaTTJ0VVRXazJURTVLTmtKU05HWXdZa3RWT0ZaVGFXRkxkekZRUWxkNk1sVTNUbFJwY2xwS1YzRkRlamhRU1RCS2FuSjNUbkZtZFcxM1NFSkdVRmcyTkZkdFZWWk9OME13UmpneWNUUnZUVEUxYkRZMGFGRXlPR0owYlM5ck9HbDBWazExWkhOSllVZG5SRmRaZEZweVdYZEdjVlJqWTA5VlpUaFlRbTF6ZDJ0bGMyNUtLek16UjJGTlYwbGtSamQwTjAxTlJVRTNTelZSY1hCa2EySTVaVkJ2VFRKbmJFRjBhMHhOY21WclpFMUdlSGhDU0VwRFJUWkphMEpDTlZSYU1YZG9Ra3h4ZFZsU1YzWkZZbnBpVTFoV01tRjBObXhYUnpZemEzaEpaRXhWVlV4VmNETjJNVVJ4ZFd4S2IwMVlWWHByU1hKRU1EUk1RM1JUVW1SbFQyWnZOMVowSzFSb01YcHdXamROVld4emVIRktTMnhGVkdKUGJVOU9jMXBpVFQwaUxDSnRZV01pT2lJd1kyVmlaRFZqTmpFellqTmpabVZoTWpGbU5HSXdOV1kwTXpaaFptTTNaVFV5TURZMk16RTBOalprTWpVMVpXWm1ZelZqTXpsbU16aGtOR0l3TjJGaklpd2lkR0ZuSWpvaUluMD0=',1756954757),('PNdB5DoSpR8r66ujnUFwSPiiblGgIHIIxSHwsNXB',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-MY) WindowsPowerShell/5.1.26100.4768','ZXlKcGRpSTZJazl4WWtwTk9IUTFkVk5ZV1U0MWJERTRUblpqVTFFOVBTSXNJblpoYkhWbElqb2llUzg0VW5wcFlXZEhlV3haTVdweWVFMTJablJGU0hKdVowRXhlRWxDYXpOMk4yZzVUamwxVEd4UWVHYzVXR1Y1YURGdFNtRk5PRVZ3WW5OdWJqWk9jVk5zTW1OSmFqWkhkMHBUVEhaUU5sZHljM0ExUVdKV1pVODBRMk5DZDJobE1HdDFPRUZoTDBnMWNGVk5ZMVYyTWxaTldVWllTMmxvTDFOVWRqZG5iMjk0TDB0TlNrVjVTVkphU3pBd2FFUkZhVXgzUzNwMkx6Wk9TVWM0ZUhaRlVFbEJWMFJLTlVsR2JtNVZSMVJwUnpsaVUxRnJjalpoZWsxMVlWSjJTRmRpVFc0NWJHMDJjR3htTVVFelptcExUVTlLUjFoVmFtWXliQ3RPVjBwMFVUQlNZMFZxVTJORFJWTlVaeXRYWkRNeWFrSmFTazVqVG1KSkwycEtNbk5rYUM5QmVHTXlZbTFaWkdJNFpqSlZObUpMTlhaVldWUXplbTl4ZUdGQ1JXMXlaVm92VDJwb1MwUnZkSEZMTUZKelVUWlNNWEZUU0RWVVZUSk5TRU5IVmtSU0t6bERTWEZGT1doelZVRTFNVTQxT0ZOSVJqSmFOSFJxVmpGSk4wMXVWbVZ3YW1KeWFGUkJlRFJDV1RCdE1WTlJUV2xDYTBzeVltdExMM2RxU1ZvMGIzSXhkM1pRT1hGQ1ZVaEJibWN2YkdoYVVYRlFhUzl1VW1oU1FqWnVlakIwYUhsTU1WRjJNRzFEWXowaUxDSnRZV01pT2lKbU9UUmxOV0l4WmpJMk9EZzVNbVE1TWpjMk9USTBaREZpTW1JMFkyRmlPRE5sWWpjM1lXVTVNakptWXpjMlpXWTBOekpsWldRd09XSmxORGxrWm1WaUlpd2lkR0ZuSWpvaUluMD0=',1756955062),('vuaP5bFGjtDOGAM28zocsU712r7BoYw70JJrzM7Y',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-MY) WindowsPowerShell/5.1.26100.4768','ZXlKcGRpSTZJbGQyY2t0UU5XbERXVFJOZG5ORVRGZG1NREp5TjJjOVBTSXNJblpoYkhWbElqb2lSRVl2Y1ZVMlRERkJkRTh5WmtwM05VaEtaRGx0VlVVMmNIcGpZbmRxYVRSamVIUktjMDFOV1VKMVNsUldUblZ6YUZOTE9YUllVa0VyYUZCNWJ6TkdUbGd5THpSQk1WSmlZWFZ3YTJwU2NVaDRLMDl5YkZFclRsRlRMM2MwTURKek4wdHNZamg0T1RsNlNVcERTWFZ3YkRWTmEzaHdWRTB4UTFkUGJFY3JWRlV6THpZM1oybEpTVXhDYURkd09YTlFiM1pxUlhsaWRrTlhTMmx3VjJGcGRXYzVTeXR3V0RSblpVNVphMHBzWm1SNFEyZDFiRFJaUkhNMmNrNWFWbGxhU3pGcVVGVnpNWEZzWjNaVmVXNDRUbFlyY1dObVRYQmhMemhKY3pKUVlWRmlhVVJDYmpWSmRXUkNhV28yTUd0T1ltVmlaREUwUm14Q1QyaE5VMnhYTnlJc0ltMWhZeUk2SWpnMk5HRmtNRFl4WkdVd01tRmtNRGRrTkRBMVlXSTJNbVU0TW1abVkyVXlaamN3TlRnM05tVTJOVEJoTlRrNE4yTmtOekpoTVdKbU9EWm1aV1EyWTJZaUxDSjBZV2NpT2lJaWZRPT0=',1756954610);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_batches`
--

DROP TABLE IF EXISTS `stock_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_batches` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `item_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity_received` int NOT NULL,
  `quantity_remaining` int NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `manufacture_date` date DEFAULT NULL,
  `status` enum('active','empty','expired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `expiry_date` date DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_batches_batch_number_unique` (`batch_number`),
  KEY `stock_batches_user_id_foreign` (`user_id`),
  KEY `stock_batches_item_id_created_at_index` (`item_id`,`created_at`),
  CONSTRAINT `stock_batches_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`) ON DELETE CASCADE,
  CONSTRAINT `stock_batches_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_batches`
--

LOCK TABLES `stock_batches` WRITE;
/*!40000 ALTER TABLE `stock_batches` DISABLE KEYS */;
INSERT INTO `stock_batches` VALUES (1,'31040','3104064',24,23,'purchase',NULL,'active',NULL,1,'2025-09-03 18:25:53','2025-09-03 18:26:59'),(2,'31040','3104026',24,24,'purchase',NULL,'active',NULL,1,'2025-09-03 18:26:21','2025-09-03 18:26:21'),(3,'45676','4567614',100,98,'testing',NULL,'active',NULL,1,'2025-09-04 03:44:30','2025-09-04 03:44:51');
/*!40000 ALTER TABLE `stock_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_movements`
--

DROP TABLE IF EXISTS `stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_movements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `item_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('in','out') COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('in_possession','gone') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'gone',
  `balance_after` int DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_movements_item_id_foreign` (`item_id`),
  KEY `stock_movements_user_id_foreign` (`user_id`),
  CONSTRAINT `stock_movements_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`) ON DELETE CASCADE,
  CONSTRAINT `stock_movements_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_movements`
--

LOCK TABLES `stock_movements` WRITE;
/*!40000 ALTER TABLE `stock_movements` DISABLE KEYS */;
INSERT INTO `stock_movements` VALUES (1,'31040','in',24,'purchase','3104064','gone',24,1,'2025-09-03 18:25:53','2025-09-03 18:25:53'),(2,'31040','in',24,'purchase','3104026','gone',48,1,'2025-09-03 18:26:21','2025-09-03 18:26:21'),(3,'45676','in',100,'testing','4567614','gone',100,1,'2025-09-04 03:44:30','2025-09-04 03:44:30');
/*!40000 ALTER TABLE `stock_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `role` enum('admin','staff') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'staff',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'HR','Knives','hrknivesofficial@gmail.com','2025-09-03 01:36:49','admin','active','$2y$12$huh9wiJvqsXBUxfhGrw5Iua0pEuwCsf.0sT/cCRbGvyqOGFrTLvQm','2025-09-03 01:36:49','2025-09-03 01:36:49');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'kedaipisauhrsuccess'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-04 11:45:16
