<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Items Export Report</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            font-size: 12px; 
            margin: 0;
            padding: 20px;
        }
        .header { 
            text-align: center; 
            margin-bottom: 30px; 
            border-bottom: 2px solid #333;
            padding-bottom: 20px;
        }
        .header h1 {
            color: #333;
            margin: 0;
            font-size: 24px;
        }
        .header p {
            margin: 5px 0;
            color: #666;
        }
        .summary {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
        }
        .summary-item {
            text-align: center;
        }
        .summary-item .number {
            font-size: 18px;
            font-weight: bold;
            color: #333;
        }
        .summary-item .label {
            font-size: 10px;
            color: #666;
            text-transform: uppercase;
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 20px;
            font-size: 10px;
        }
        th, td { 
            border: 1px solid #ddd; 
            padding: 8px; 
            text-align: left; 
            vertical-align: top;
        }
        th { 
            background-color: #f8f9fa; 
            font-weight: bold;
            color: #333;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .status-badge { 
            padding: 2px 6px; 
            border-radius: 10px; 
            font-size: 9px;
            font-weight: bold;
            text-align: center;
        }
        .out-of-stock { 
            background-color: #fee2e2; 
            color: #991b1b; 
        }
        .low-stock { 
            background-color: #fef3c7; 
            color: #92400e; 
        }
        .ready-stock { 
            background-color: #dcfce7; 
            color: #166534; 
        }
        .price {
            text-align: right;
            font-weight: bold;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 10px;
            color: #666;
            border-top: 1px solid #ddd;
            padding-top: 15px;
        }
        .page-break {
            page-break-after: always;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Items Inventory Report</h1>
        <p><strong>Generated on:</strong> <?php echo e(now()->format('F j, Y \a\t g:i A')); ?></p>
        <p><strong>Total Items:</strong> <?php echo e($items->count()); ?></p>
        <?php if(request('brand')): ?>
            <p><strong>Brand Filter:</strong> <?php echo e(request('brand')); ?></p>
        <?php endif; ?>
        <?php if(request('status')): ?>
            <p><strong>Status Filter:</strong> <?php echo e(ucwords(str_replace('_', ' ', request('status')))); ?></p>
        <?php endif; ?>
    </div>

    <div class="summary">
        <div class="summary-grid">
            <div class="summary-item">
                <div class="number"><?php echo e($items->where('status', 'ready_stock')->count()); ?></div>
                <div class="label">Ready Stock</div>
            </div>
            <div class="summary-item">
                <div class="number"><?php echo e($items->where('status', 'low_stock')->count()); ?></div>
                <div class="label">Low Stock</div>
            </div>
            <div class="summary-item">
                <div class="number"><?php echo e($items->where('status', 'out_of_stock')->count()); ?></div>
                <div class="label">Out of Stock</div>
            </div>
            <div class="summary-item">
                <div class="number">RM <?php echo e(number_format($items->sum('retail_price'), 2)); ?></div>
                <div class="label">Total Value</div>
            </div>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th style="width: 8%;">Item ID</th>
                <th style="width: 10%;">SKU</th>
                <th style="width: 10%;">Barcode</th>
                <th style="width: 20%;">Item Name</th>
                <th style="width: 8%;">Brand</th>
                <th style="width: 8%;">Model</th>
                <th style="width: 6%;">Color</th>
                <th style="width: 8%;">Cost (RM)</th>
                <th style="width: 8%;">Retail (RM)</th>
                <th style="width: 5%;">Qty</th>
                <th style="width: 7%;">Status</th>
                <th style="width: 8%;">Created</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->item_id); ?></td>
                <td><?php echo e($item->sku_id); ?></td>
                <td><?php echo e($item->barcode ?? '-'); ?></td>
                <td><strong><?php echo e($item->item_name); ?></strong></td>
                <td><?php echo e($item->brand); ?></td>
                <td><?php echo e($item->model); ?></td>
                <td><?php echo e($item->color); ?></td>
                <td class="price"><?php echo e(number_format($item->cost_price, 2)); ?></td>
                <td class="price"><?php echo e(number_format($item->retail_price, 2)); ?></td>
                <td style="text-align: center;"><?php echo e($item->quantity); ?></td>
                <td>
                    <span class="status-badge <?php echo e(str_replace('_', '-', $item->status)); ?>">
                        <?php echo e(ucwords(str_replace('_', ' ', $item->status))); ?>

                    </span>
                </td>
                <td><?php echo e($item->created_at->format('M j, Y')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php if($items->count() == 0): ?>
        <div style="text-align: center; padding: 40px; color: #666;">
            <p>No items found matching the specified criteria.</p>
        </div>
    <?php endif; ?>

    <div class="footer">
        <p>This report was generated automatically by the Item Management System.</p>
        <p>© <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?> - Confidential</p>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\kedaipisauhrsuccess\resources\views/exports/items.blade.php ENDPATH**/ ?>