import { useState } from 'react';
import { router } from '@inertiajs/react';
import { Head } from '@inertiajs/react';
import { toast } from '@/utils/toast';
import { downloadRouteFile } from '@/utils/desktopDownload';

export default function DatabaseBackupForm({ databaseBackups = [], className = '' }) {
    const [isCreating, setIsCreating] = useState(false);

    const createBackup = () => {
        setIsCreating(true);
        
        router.post(route('profile.database.backup'), {}, {
            onSuccess: () => {
                setIsCreating(false);
                // The success message will be shown via Laravel's flash messages
            },
            onError: (errors) => {
                setIsCreating(false);
                // The error message will be shown via Laravel's flash messages
            }
        });
    };

    const deleteBackup = (filename) => {
        if (confirm(`Are you sure you want to delete "${filename}"? This action cannot be undone.`)) {
            router.delete(route('profile.database.backup.delete', { filename }), {
                onSuccess: () => {
                    // The success message will be shown via Laravel's flash messages
                },
                onError: (errors) => {
                    // The error message will be shown via Laravel's flash messages
                }
            });
        }
    };

    const downloadBackup = async (filename) => {
        try {
            const result = await downloadRouteFile(
                route('profile.database.backup.download', { filename }),
                filename
            );

            if (result?.canceled) {
                return;
            }
        } catch (error) {
            console.error('Backup download failed:', error);
            toast.error(error.message || 'Backup download failed.');
        }
    };

    return (
        <section className={className}>
            <header>
                <div className="flex items-center justify-between">
                    <div>
                        <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                            Database Backup
                        </h2>

                        <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                            Create and manage database backups for your application.
                        </p>
                    </div>
                    
                    <button
                        onClick={createBackup}
                        disabled={isCreating}
                        className="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 focus:bg-blue-700 active:bg-blue-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isCreating ? (
                            <>
                                <svg className="animate-spin -ml-1 mr-3 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Creating...
                            </>
                        ) : (
                            <>
                                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                </svg>
                                Create Backup
                            </>
                        )}
                    </button>
                </div>
            </header>

            <div className="mt-6 space-y-6">

                {/* Backup List */}
                {databaseBackups.length === 0 ? (
                    <div className="text-center py-8">
                        <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                        <h3 className="mt-2 text-sm font-medium text-gray-900 dark:text-gray-100">No backups</h3>
                        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                            Get started by creating your first database backup.
                        </p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">Available Backups</h3>
                        {databaseBackups.map((backup, index) => (
                            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center space-x-3">
                                        <svg className="h-5 w-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                        </svg>
                                        <div className="flex-1 min-w-0">
                                            <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">
                                                {backup.filename}
                                            </p>
                                            <p className="text-sm text-gray-500 dark:text-gray-400">
                                                {backup.size} • Created {backup.created_at}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <button
                                        onClick={() => downloadBackup(backup.filename)}
                                        className="inline-flex items-center px-3 py-1.5 border border-gray-300 dark:border-gray-600 shadow-sm text-xs font-medium rounded text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-600 hover:bg-gray-50 dark:hover:bg-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                                    >
                                        <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                        </svg>
                                        Download
                                    </button>
                                    <button
                                        onClick={() => deleteBackup(backup.filename)}
                                        className="inline-flex items-center px-3 py-1.5 border border-red-300 dark:border-red-600 shadow-sm text-xs font-medium rounded text-red-700 dark:text-red-300 bg-white dark:bg-gray-600 hover:bg-red-50 dark:hover:bg-red-900/20 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                                    >
                                        <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                        </svg>
                                        Delete
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </section>
    );
}
